# ChesSQL-db
ChesSQL-db is a chess library for python that neatly stores games in a PostgreSQL database.
